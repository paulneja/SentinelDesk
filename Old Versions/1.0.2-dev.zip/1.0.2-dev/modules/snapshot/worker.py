from PySide6.QtCore import QThread, Signal

from .collector import collect_snapshot
from .report import save_snapshot, build_summary


class SnapshotWorker(QThread):
    progress = Signal(str)
    result = Signal(dict)
    error = Signal(str)

    def __init__(self, max_events: int = 20):
        super().__init__()
        self.max_events = max_events

    def run(self):
        try:
            snap = collect_snapshot(progress_cb=lambda m: self.progress.emit(m), max_events=self.max_events)
            # Attach summary inside snapshot for fast browsing
            try:
                snap["summary"] = build_summary(snap)
            except Exception:
                snap["summary"] = {}

            paths = save_snapshot(snap)

            self.result.emit({
                "snapshot": snap,
                **paths,
            })
        except Exception as e:
            self.error.emit(str(e))
