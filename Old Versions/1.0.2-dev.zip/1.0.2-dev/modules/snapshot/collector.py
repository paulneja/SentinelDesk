import os
import re
import json
import time
import socket
import getpass
import hashlib
import platform
import subprocess
from datetime import datetime, timezone
import psutil
import os
import subprocess

def _no_console_kwargs():
    if os.name != "nt":
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return {"startupinfo": si, "creationflags": subprocess.CREATE_NO_WINDOW}


try:
    import winreg  # type: ignore
except Exception:  # pragma: no cover
    winreg = None

SCHEMA_ID = "sentineldesk.snapshot.v1"


def _iso_utc(ts: float | None = None) -> str:
    if ts is None:
        dt = datetime.now(timezone.utc)
    else:
        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _run_powershell_json(script: str, stdin_obj=None, timeout: int = 60) -> tuple[object | None, str | None]:
    """Run PowerShell and parse JSON output."""
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            input=(json.dumps(stdin_obj, ensure_ascii=False) if stdin_obj is not None else None),
            capture_output=True,
            text=True,
            timeout=timeout,
            **_no_console_kwargs()
        )
        if proc.returncode != 0:
            err = (proc.stderr or proc.stdout or "").strip()
            return None, err or f"powershell_failed: code={proc.returncode}"
        out = (proc.stdout or "").strip()
        if not out:
            return None, "powershell_no_output"
        return json.loads(out), None
    except subprocess.TimeoutExpired:
        return None, "powershell_timeout"
    except Exception as e:
        return None, f"powershell_error: {e}"


def _sha256_file(path: str) -> str | None:
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def _norm_exe(s: str | None) -> str:
    if not s:
        return ""
    s = s.strip().strip('"')
    return s


def _win_current_version() -> dict:
    if winreg is None:
        return {}
    out = {}
    try:
        key_path = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as k:
            for name in (
                "ProductName",
                "DisplayVersion",
                "ReleaseId",
                "CurrentBuild",
                "CurrentBuildNumber",
                "UBR",
                "EditionID",
                "InstallationType",
                "RegisteredOrganization",
            ):
                try:
                    v, _t = winreg.QueryValueEx(k, name)
                    out[name] = v
                except Exception:
                    pass
    except Exception:
        pass
    return out


def collect_system_info() -> dict:
    win = _win_current_version()
    hostname = socket.gethostname()
    user = getpass.getuser()
    arch = platform.machine()
    boot = psutil.boot_time()
    uptime_s = max(0.0, time.time() - boot)

    win_str = ""
    if win:
        prod = win.get("ProductName") or "Windows"
        ver = win.get("DisplayVersion") or win.get("ReleaseId") or ""
        build = win.get("CurrentBuild") or win.get("CurrentBuildNumber")
        ubr = win.get("UBR")
        win_str = f"{prod} {ver}".strip()
        if build and ubr is not None:
            win_str += f" (Build {build}.{ubr})"
        elif build:
            win_str += f" (Build {build})"
    else:
        win_str = f"{platform.system()} {platform.release()}"

    return {
        "windows": win_str,
        "windows_raw": win,
        "hostname": hostname,
        "user": user,
        "architecture": arch,
        "uptime_seconds": uptime_s,
        "boot_time_utc": _iso_utc(boot),
        "snapshot_time_utc": _iso_utc(),
    }


def _authenticode_signatures(paths: list[str]) -> tuple[dict[str, dict], str | None]:
    """Get Authenticode status for a list of paths using one PowerShell call."""
    script = r'''
$pathsJson = [Console]::In.ReadToEnd()
try { $paths = $pathsJson | ConvertFrom-Json } catch { $paths = @() }
$out = @()
foreach ($p in $paths) {
  if ([string]::IsNullOrWhiteSpace($p)) { continue }
  if (Test-Path -LiteralPath $p) {
    try {
      $sig = Get-AuthenticodeSignature -FilePath $p
      $out += [pscustomobject]@{
        Path = $p
        Status = "$($sig.Status)"
        Signer = $(if($sig.SignerCertificate){$sig.SignerCertificate.Subject}else{""})
        Thumbprint = $(if($sig.SignerCertificate){$sig.SignerCertificate.Thumbprint}else{""})
      }
    } catch {
      $out += [pscustomobject]@{ Path=$p; Status="Error"; Signer=""; Thumbprint="" }
    }
  } else {
    $out += [pscustomobject]@{ Path=$p; Status="Missing"; Signer=""; Thumbprint="" }
  }
}
$out | ConvertTo-Json -Depth 3
'''
    data, err = _run_powershell_json(script, stdin_obj=paths, timeout=120)
    if err or data is None:
        return {}, err

    mapping = {}
    if isinstance(data, dict):
        # ConvertTo-Json sometimes returns a dict if only one object
        p = data.get("Path")
        if p:
            mapping[str(p)] = {
                "status": data.get("Status"),
                "signer_subject": data.get("Signer"),
                "thumbprint": data.get("Thumbprint"),
            }
    elif isinstance(data, list):
        for it in data:
            if not isinstance(it, dict):
                continue
            p = it.get("Path")
            if not p:
                continue
            mapping[str(p)] = {
                "status": it.get("Status"),
                "signer_subject": it.get("Signer"),
                "thumbprint": it.get("Thumbprint"),
            }
    return mapping, None


def collect_processes(progress_cb=None) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    procs: list[dict] = []
    exe_set: set[str] = set()

    if progress_cb:
        progress_cb("procesos: enumerando...")

    for p in psutil.process_iter(attrs=["pid", "ppid", "name", "exe", "username", "create_time"]):
        try:
            info = p.info
            exe = info.get("exe") or ""
            exe = _norm_exe(exe)
            if exe:
                exe_set.add(exe)

            procs.append(
                {
                    "pid": info.get("pid"),
                    "ppid": info.get("ppid"),
                    "name": info.get("name"),
                    "exe": exe,
                    "username": info.get("username"),
                    "create_time_utc": _iso_utc(info.get("create_time")) if info.get("create_time") else None,
                    "sha256": None,
                    "signature": {"status": None, "signer_subject": None, "thumbprint": None},
                }
            )
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
        except Exception as e:
            errors.append(f"process_iter_error: {e}")

    # Hash unique exe paths
    if progress_cb:
        progress_cb(f"procesos: hash sha256 ({len(exe_set)} binarios únicos)...")

    hash_map: dict[str, str | None] = {}
    for exe in sorted(exe_set):
        h = _sha256_file(exe)
        hash_map[exe] = h

    # Signature unique exe paths (chunked)
    if progress_cb:
        progress_cb(f"procesos: firmas (Authenticode) ({len(exe_set)} binarios únicos)...")

    sig_map: dict[str, dict] = {}
    exe_list = sorted(exe_set)
    chunk = 80
    for i in range(0, len(exe_list), chunk):
        part = exe_list[i : i + chunk]
        m, err = _authenticode_signatures(part)
        if err:
            errors.append(f"authenticode_error: {err}")
        sig_map.update(m)

    # Attach
    for it in procs:
        exe = it.get("exe") or ""
        if exe:
            it["sha256"] = hash_map.get(exe)
            it["signature"] = sig_map.get(exe) or it["signature"]

    if progress_cb:
        progress_cb("procesos: listo")

    return procs, errors


def collect_connections(progress_cb=None) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    out: list[dict] = []

    if progress_cb:
        progress_cb("conexiones: leyendo...")

    # Cache pid -> (name, exe, user)
    proc_cache: dict[int, dict] = {}

    for c in psutil.net_connections(kind="inet"):
        try:
            pid = c.pid or 0

            if pid and pid not in proc_cache:
                try:
                    p = psutil.Process(pid)
                    proc_cache[pid] = {
                        "process_name": p.name(),
                        "process_exe": _norm_exe(p.exe()),
                        "process_username": p.username(),
                    }
                except Exception:
                    proc_cache[pid] = {"process_name": None, "process_exe": None, "process_username": None}

            info = proc_cache.get(pid, {"process_name": None, "process_exe": None, "process_username": None})

            proto = "TCP" if c.type == socket.SOCK_STREAM else "UDP"
            l_ip, l_port = (None, None)
            r_ip, r_port = (None, None)

            if c.laddr:
                l_ip, l_port = c.laddr[0], c.laddr[1]
            if c.raddr:
                r_ip, r_port = c.raddr[0], c.raddr[1]

            out.append(
                {
                    "protocol": proto,
                    "state": c.status,
                    "pid": pid or None,
                    "local_ip": l_ip,
                    "local_port": l_port,
                    "remote_ip": r_ip,
                    "remote_port": r_port,
                    **info,
                }
            )
        except Exception as e:
            errors.append(f"net_conn_error: {e}")

    if progress_cb:
        progress_cb("conexiones: listo")

    return out, errors


def collect_services(progress_cb=None) -> tuple[dict, list[str]]:
    if progress_cb:
        progress_cb("servicios: leyendo (Win32_Service)...")

    script = r'''
$items = Get-CimInstance Win32_Service | Select-Object Name, DisplayName, State, StartMode, PathName, ProcessId
$items | ConvertTo-Json -Depth 3
'''
    data, err = _run_powershell_json(script, timeout=120)
    if err or data is None:
        return {"error": err, "items": []}, [f"services_error: {err}"]

    items = data if isinstance(data, list) else ([data] if isinstance(data, dict) else [])
    norm = []
    for s in items:
        if not isinstance(s, dict):
            continue
        norm.append(
            {
                "name": s.get("Name"),
                "display_name": s.get("DisplayName"),
                "state": s.get("State"),
                "start_mode": s.get("StartMode"),
                "path": _norm_exe(s.get("PathName")),
                "pid": s.get("ProcessId"),
            }
        )

    if progress_cb:
        progress_cb("servicios: listo")

    return {"items": norm}, []


def _read_run_key(root, path: str) -> list[dict]:
    if winreg is None:
        return []

    items = []
    try:
        with winreg.OpenKey(root, path) as k:
            i = 0
            while True:
                try:
                    name, value, _t = winreg.EnumValue(k, i)
                    raw = str(value)
                    expanded = os.path.expandvars(raw)
                    items.append(
                        {
                            "name": name,
                            "value": raw,
                            "expanded": expanded,
                            "location": path,
                        }
                    )
                    i += 1
                except OSError:
                    break
    except Exception:
        return []
    return items


def collect_persistence(progress_cb=None) -> tuple[dict, list[str]]:
    errors: list[str] = []
    if progress_cb:
        progress_cb("persistencia: run keys...")

    run_items = []
    run_items += _read_run_key(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") if winreg else []
    run_items += _read_run_key(winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run") if winreg else []
    run_items += _read_run_key(winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce") if winreg else []

    # Startup folders
    if progress_cb:
        progress_cb("persistencia: startup folders...")

    startup_items = []
    startup_dirs = []
    try:
        appdata = os.environ.get("APPDATA") or ""
        programdata = os.environ.get("PROGRAMDATA") or ""
        if appdata:
            startup_dirs.append(os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup"))
        if programdata:
            startup_dirs.append(os.path.join(programdata, r"Microsoft\Windows\Start Menu\Programs\Startup"))
    except Exception:
        pass

    for d in startup_dirs:
        try:
            if os.path.isdir(d):
                for name in os.listdir(d):
                    p = os.path.join(d, name)
                    try:
                        st = os.stat(p)
                        startup_items.append(
                            {
                                "name": name,
                                "path": p,
                                "mtime_utc": _iso_utc(st.st_mtime),
                                "size": st.st_size,
                            }
                        )
                    except Exception:
                        startup_items.append({"name": name, "path": p})
        except Exception as e:
            errors.append(f"startup_folder_error: {d}: {e}")

    # Scheduled tasks
    if progress_cb:
        progress_cb("persistencia: scheduled tasks...")

    script = r'''
$tasks = @()
try { $tasks = Get-ScheduledTask } catch { $tasks = @() }
$out = @()
foreach ($t in $tasks) {
  $actions = @()
  foreach ($a in $t.Actions) {
    if ($a -ne $null) {
      $actions += (($a.Execute) + " " + ($a.Arguments))
    }
  }
  $out += [pscustomobject]@{
    TaskName = $t.TaskName
    TaskPath = $t.TaskPath
    State = "$($t.State)"
    Author = $t.Author
    Actions = ($actions -join "; ")
    PrincipalUserId = $t.Principal.UserId
    RunLevel = "$($t.Principal.RunLevel)"
  }
}
$out | ConvertTo-Json -Depth 4
'''
    tasks_data, err = _run_powershell_json(script, timeout=180)
    if err or tasks_data is None:
        errors.append(f"scheduled_tasks_error: {err}")
        tasks_items = []
    else:
        tasks_items = tasks_data if isinstance(tasks_data, list) else ([tasks_data] if isinstance(tasks_data, dict) else [])
        tasks_items = [
            {
                "task_name": t.get("TaskName"),
                "task_path": t.get("TaskPath"),
                "state": t.get("State"),
                "author": t.get("Author"),
                "actions": t.get("Actions"),
                "principal_user": t.get("PrincipalUserId"),
                "run_level": t.get("RunLevel"),
            }
            for t in tasks_items
            if isinstance(t, dict)
        ]

    if progress_cb:
        progress_cb("persistencia: listo")

    return {
        "run_keys": {"items": run_items},
        "startup_folders": {"paths": startup_dirs, "items": startup_items},
        "scheduled_tasks": {"items": tasks_items},
    }, errors


def _trim_msg(s: str, n: int = 1800) -> str:
    s = re.sub(r"\s+\Z", "", s)
    if len(s) <= n:
        return s
    return s[: n - 3] + "..."


def collect_events(progress_cb=None, max_items: int = 20) -> tuple[dict, list[str]]:
    if progress_cb:
        progress_cb("eventos: leyendo (System/Application/Security)...")

    script = r'''
param([int]$Max = 20)

$since = (Get-Date).AddDays(-7)

function Pull($logName) {
  try {
    $events = Get-WinEvent -FilterHashtable @{ LogName=$logName; Level=1,2; StartTime=$since } -MaxEvents $Max
    $out = @()
    foreach ($e in $events) {
      $msg = ""
      try { $msg = $e.Message } catch { $msg = "" }
      $out += [pscustomobject]@{
        TimeCreated = "$($e.TimeCreated.ToUniversalTime().ToString('o'))"
        Id = $e.Id
        LevelDisplayName = $e.LevelDisplayName
        ProviderName = $e.ProviderName
        Message = $msg
      }
    }
    return $out
  } catch {
    return [pscustomobject]@{ error = "$($_.Exception.Message)" }
  }
}

$system = Pull "System"
$app = Pull "Application"
$sec = Pull "Security"

[pscustomobject]@{
  system = $system
  application = $app
  security = $sec
} | ConvertTo-Json -Depth 4
'''

    script2 = script.replace("param([int]$Max = 20)", f"$Max = {int(max_items)}")
    data, err = _run_powershell_json(script2, timeout=120)

    if err or data is None:
        return {
            "system": {"error": err},
            "application": {"error": err},
            "security": {"error": err},
        }, [f"events_error: {err}"]

    out = {}
    for key in ("system", "application", "security"):
        blob = data.get(key)
        if isinstance(blob, dict) and blob.get("error"):
            out[key] = {"error": str(blob.get("error")), "items": []}
        else:
            items = blob
            if isinstance(items, dict):
                items = [items]
            if not isinstance(items, list):
                items = []
            norm = []
            for e in items:
                if not isinstance(e, dict):
                    continue
                msg = str(e.get("Message") or "")
                norm.append(
                    {
                        "time_utc": e.get("TimeCreated"),
                        "id": int(e.get("Id")) if str(e.get("Id") or "").isdigit() else e.get("Id"),
                        "level": e.get("LevelDisplayName"),
                        "provider": e.get("ProviderName"),
                        "message": _trim_msg(msg),
                    }
                )
            out[key] = {"items": norm}

    if progress_cb:
        progress_cb("eventos: listo")

    return out, []


def collect_snapshot(progress_cb=None, max_events: int = 20) -> dict:
    warnings: list[str] = []
    errors: list[str] = []

    system = collect_system_info()

    meta = {
        "schema": SCHEMA_ID,
        "tool": "SentinelDesk",
        "module": "snapshot",
        "build": "1.0.2-unstable",
        "created_utc": system.get("snapshot_time_utc"),
        "hostname": system.get("hostname"),
        "user": system.get("user"),
    }

    if progress_cb:
        progress_cb("snapshot: iniciando...")

    procs, err = collect_processes(progress_cb=progress_cb)
    errors += err

    conns, err = collect_connections(progress_cb=progress_cb)
    errors += err

    services, err = collect_services(progress_cb=progress_cb)
    errors += err

    persistence, err = collect_persistence(progress_cb=progress_cb)
    errors += err

    events, err = collect_events(progress_cb=progress_cb, max_items=max_events)
    errors += err

    if progress_cb:
        progress_cb("snapshot: finalizando...")

    snap = {
        "meta": meta,
        "system": system,
        "processes": procs,
        "connections": conns,
        "services": services,
        "persistence": persistence,
        "events": events,
        "warnings": warnings,
        "errors": errors,
    }

    return snap
