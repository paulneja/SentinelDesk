import os
import sys
import json
import re
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
import ipaddress

SCHEMA_ID = "sentineldesk.snapshot.v1"


def _app_base_dir() -> Path:
    """Return a writable base directory.

    Dev mode: .../sentineldesk
    Frozen (PyInstaller): directory of the executable
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def get_snapshots_dir() -> Path:
    d = _app_base_dir() / "snapshots"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _safe_name(s: str) -> str:
    s = s.strip().replace(" ", "_")
    s = re.sub(r"[^a-zA-Z0-9_\-\.]+", "_", s)
    return s[:80] if len(s) > 80 else s


def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_snapshot(snapshot: dict) -> dict:
    """Write snapshot JSON + sidecar sha256 file.

    Returns:
      {json_path, sha256_path, file_sha256, dir}
    """
    snapshots_dir = get_snapshots_dir()

    meta = snapshot.setdefault("meta", {})
    meta.setdefault("schema", SCHEMA_ID)
    meta.setdefault("created_utc", datetime.now(timezone.utc).isoformat())

    hostname = meta.get("hostname") or "host"
    created = meta.get("created_utc") or datetime.now(timezone.utc).isoformat()

    # Filename: snapshot_YYYYMMDD_HHMMSS_HOST.json
    try:
        dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
    except Exception:
        dt = datetime.now(timezone.utc)
    stamp = dt.strftime("%Y%m%d_%H%M%S")
    fname = f"snapshot_{stamp}_{_safe_name(str(hostname))}.json"

    out_path = snapshots_dir / fname
    i = 1
    while out_path.exists():
        out_path = snapshots_dir / f"snapshot_{stamp}_{_safe_name(str(hostname))}_{i}.json"
        i += 1

    # Content hash (stable over canonical JSON of the data)
    canonical = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    meta["content_sha256"] = _sha256_bytes(canonical)

    # Write JSON (pretty)
    out_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")

    # File hash (actual bytes written)
    file_hash = _sha256_file(out_path)

    sha_path = out_path.with_suffix(".sha256")
    sha_path.write_text(f"{file_hash}  {out_path.name}\n", encoding="utf-8")

    return {
        "dir": str(snapshots_dir),
        "json_path": str(out_path),
        "sha256_path": str(sha_path),
        "file_sha256": file_hash,
    }


def list_snapshots(limit: int = 200) -> list[Path]:
    d = get_snapshots_dir()
    files = sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[:limit]


def load_snapshot(path: str | Path) -> dict:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    meta = data.get("meta") or {}
    if meta.get("schema") != SCHEMA_ID:
        # Igual lo dejamos abrir (para no romper el browser), pero marcamos que no es nativo
        data.setdefault("warnings", []).append("schema_mismatch: not a SentinelDesk snapshot v1")
    return data


def _is_public_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast)
    except Exception:
        return False


def build_summary(snapshot: dict) -> dict:
    meta = snapshot.get("meta") or {}
    sysinfo = snapshot.get("system") or {}
    processes = snapshot.get("processes") or []
    conns = snapshot.get("connections") or []
    services = snapshot.get("services") or {}
    persistence = snapshot.get("persistence") or {}
    events = snapshot.get("events") or {}

    counts = {
        "processes": len(processes) if isinstance(processes, list) else 0,
        "connections": len(conns) if isinstance(conns, list) else 0,
        "services_total": len(services.get("items") or []) if isinstance(services, dict) else 0,
        "run_keys": len((persistence.get("run_keys") or {}).get("items") or []),
        "startup_items": len((persistence.get("startup_folders") or {}).get("items") or []),
        "scheduled_tasks": len((persistence.get("scheduled_tasks") or {}).get("items") or []),
    }

    # Process signature breakdown
    sig = {"valid": 0, "not_signed": 0, "other": 0, "unknown": 0}
    tempish = []
    for p in processes if isinstance(processes, list) else []:
        s = (((p.get("signature") or {}).get("status")) or "").lower()
        exe = (p.get("exe") or "")
        if s == "valid":
            sig["valid"] += 1
        elif s in ("notsigned", "not_signed", "missing"):
            sig["not_signed"] += 1
        elif s:
            sig["other"] += 1
        else:
            sig["unknown"] += 1

        # quick “weird path” hint
        exel = exe.lower()
        if exel and any(k in exel for k in ("\\appdata\\local\\temp\\", "\\temp\\", "\\downloads\\", "\\desktop\\")):
            tempish.append({"pid": p.get("pid"), "name": p.get("name"), "exe": exe, "sig": (p.get("signature") or {}).get("status")})

    # Connections quick view
    established = 0
    public_remote = 0
    top_remote = {}
    for c in conns if isinstance(conns, list) else []:
        if str(c.get("state") or "").upper() == "ESTABLISHED":
            established += 1
        rip = (c.get("remote_ip") or "")
        if rip and _is_public_ip(str(rip)):
            public_remote += 1
            top_remote[str(rip)] = top_remote.get(str(rip), 0) + 1

    top_remote_sorted = sorted(top_remote.items(), key=lambda kv: kv[1], reverse=True)[:8]

    # Services summary
    svc_running = 0
    svc_autostart = 0
    svc_autostart_stopped = 0
    for s in (services.get("items") or []) if isinstance(services, dict) else []:
        st = str(s.get("state") or "").lower()
        sm = str(s.get("start_mode") or "").lower()
        if st == "running":
            svc_running += 1
        if sm == "auto":
            svc_autostart += 1
            if st != "running":
                svc_autostart_stopped += 1

    # Events counts
    def _count_items(blob: Any) -> int:
        if isinstance(blob, dict):
            return len(blob.get("items") or [])
        if isinstance(blob, list):
            return len(blob)
        return 0

    ev_counts = {
        "system": _count_items(events.get("system")),
        "application": _count_items(events.get("application")),
        "security": _count_items(events.get("security")),
    }

    return {
        "created_utc": meta.get("created_utc"),
        "hostname": meta.get("hostname") or sysinfo.get("hostname"),
        "os": sysinfo.get("windows"),
        "uptime_seconds": sysinfo.get("uptime_seconds"),
        "counts": counts,
        "process_signatures": sig,
        "connections": {
            "established": established,
            "public_remote": public_remote,
            "top_remote": top_remote_sorted,
        },
        "services": {
            "running": svc_running,
            "autostart": svc_autostart,
            "autostart_stopped": svc_autostart_stopped,
        },
        "events": ev_counts,
        "hints": {
            "tempish_processes": tempish[:20],
        },
    }


def summary_to_text(snapshot: dict) -> str:
    summary = snapshot.get("summary") or build_summary(snapshot)

    lines = []
    lines.append("SentinelDesk Snapshot Report")
    lines.append("────────────────────────────")
    lines.append(f"UTC: {summary.get('created_utc')}")
    lines.append(f"Host: {summary.get('hostname')}")
    lines.append(f"OS:   {summary.get('os')}")
    up = summary.get("uptime_seconds")
    if isinstance(up, (int, float)) and up >= 0:
        h = int(up) // 3600
        m = (int(up) % 3600) // 60
        lines.append(f"Uptime: {h}h {m}m")
    lines.append("")

    counts = summary.get("counts") or {}
    lines.append("Conteos")
    lines.append(f"- Procesos: {counts.get('processes')}")
    lines.append(f"- Conexiones: {counts.get('connections')}")
    lines.append(f"- Servicios (total): {counts.get('services_total')}")
    lines.append(f"- Persistencia: RunKeys={counts.get('run_keys')} | Startup={counts.get('startup_items')} | Tasks={counts.get('scheduled_tasks')}")
    lines.append("")

    sig = summary.get("process_signatures") or {}
    lines.append("Firmas (procesos)")
    lines.append(f"- Valid: {sig.get('valid')}")
    lines.append(f"- NotSigned/Missing: {sig.get('not_signed')}")
    lines.append(f"- Other: {sig.get('other')}")
    lines.append(f"- Unknown: {sig.get('unknown')}")
    lines.append("")

    c = summary.get("connections") or {}
    lines.append("Conexiones")
    lines.append(f"- ESTABLISHED: {c.get('established')}")
    lines.append(f"- Remote públicas: {c.get('public_remote')}")
    top = c.get("top_remote") or []
    if top:
        lines.append("- Top remotes:")
        for ip, n in top:
            lines.append(f"  • {ip}  x{n}")
    lines.append("")

    s = summary.get("services") or {}
    lines.append("Servicios")
    lines.append(f"- Running: {s.get('running')}")
    lines.append(f"- AutoStart: {s.get('autostart')} (stopped: {s.get('autostart_stopped')})")
    lines.append("")

    ev = summary.get("events") or {}
    lines.append("Eventos recientes (crit/error)")
    lines.append(f"- System: {ev.get('system')}")
    lines.append(f"- Application: {ev.get('application')}")
    lines.append(f"- Security: {ev.get('security')}")
    lines.append("")

    hints = (summary.get("hints") or {})
    tempish = hints.get("tempish_processes") or []
    if tempish:
        lines.append("Hints (paths típicamente raros: Temp/AppData/Downloads/Desktop)")
        for p in tempish[:15]:
            lines.append(f"- PID {p.get('pid')} | {p.get('name')} | {p.get('sig')} | {p.get('exe')}")
        lines.append("")

    # Warnings (collector side)
    warns = snapshot.get("warnings") or []
    errs = (snapshot.get("errors") or [])
    if warns or errs:
        lines.append("Notas / Limitaciones")
        for w in warns[:20]:
            lines.append(f"- {w}")
        for e in errs[:20]:
            lines.append(f"- {e}")
        lines.append("")

    return "\n".join(lines)
