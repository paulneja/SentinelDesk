import os
from pathlib import Path

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QTableView,
    QMessageBox,
    QSplitter,
    QHeaderView,
    QApplication,
)

from .worker import SnapshotWorker
from .report import list_snapshots, load_snapshot, summary_to_text, get_snapshots_dir


class SnapshotIndexModel(QAbstractTableModel):
    COLS = [
        ("Fecha (UTC)", "created_utc"),
        ("Host", "hostname"),
        ("OS", "os"),
        ("Proc", "proc"),
        ("Conn", "conn"),
        ("Archivo", "file"),
    ]

    def __init__(self):
        super().__init__()
        self.rows: list[dict] = []

    def rowCount(self, parent=QModelIndex()):
        return len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(self.COLS)

    def headerData(self, section, orientation, role):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return self.COLS[section][0]
        return str(section + 1)

    def data(self, index: QModelIndex, role: int):
        if not index.isValid():
            return None
        r = self.rows[index.row()]
        key = self.COLS[index.column()][1]

        if role == Qt.DisplayRole:
            if key == "proc":
                return str(r.get("proc", ""))
            if key == "conn":
                return str(r.get("conn", ""))
            if key == "file":
                return str(r.get("file", ""))
            return str(r.get(key, ""))

        if role == Qt.TextAlignmentRole:
            if key in ("proc", "conn"):
                return int(Qt.AlignCenter)
            return int(Qt.AlignLeft | Qt.AlignVCenter)

        return None

    def set_rows(self, rows: list[dict]):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def row_path(self, row: int) -> str:
        if row < 0 or row >= len(self.rows):
            return ""
        return self.rows[row].get("path", "")


class SnapshotPage(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        title = QLabel("Incident Snapshot")
        title.setFont(QFont("Segoe UI", 15, QFont.Bold))
        title.setObjectName("pagetitle")

        subtitle = QLabel(
            "Captura forense pasiva del estado actual. No modifica nada, no escanea red, no ejecuta acciones activas."
            "\nGenera JSON en ./snapshots y permite leerlos y resumirlos."
        )
        subtitle.setWordWrap(True)
        subtitle.setObjectName("muted")

        root.addWidget(title)
        root.addWidget(subtitle)

        # Controls panel
        controls = QFrame()
        controls.setObjectName("panel")
        c_lay = QHBoxLayout(controls)
        c_lay.setContentsMargins(12, 10, 12, 10)
        c_lay.setSpacing(10)

        self.btn_run = QPushButton("Generar snapshot")
        self.btn_run.setObjectName("btn")

        self.btn_refresh = QPushButton("Refrescar")
        self.btn_refresh.setObjectName("btn")

        self.btn_open_dir = QPushButton("Abrir carpeta snapshots")
        self.btn_open_dir.setObjectName("btn")

        self.status = QLabel("Estado: listo")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)

        c_lay.addWidget(self.btn_run)
        c_lay.addWidget(self.btn_refresh)
        c_lay.addWidget(self.btn_open_dir)
        c_lay.addStretch(1)
        c_lay.addWidget(self.status)

        root.addWidget(controls)

        splitter = QSplitter(Qt.Horizontal)

        # Left: snapshots table
        left = QFrame()
        left.setObjectName("panel")
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(12, 12, 12, 12)
        left_lay.setSpacing(8)

        left_lay.addWidget(QLabel("Snapshots guardados"))

        self.table = QTableView()
        self.model = SnapshotIndexModel()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setStretchLastSection(True)

        left_lay.addWidget(self.table)

        # Right: summary
        right = QFrame()
        right.setObjectName("panel")
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(12, 12, 12, 12)
        right_lay.setSpacing(8)

        right_lay.addWidget(QLabel("Resumen"))

        self.summary = QTextEdit()
        self.summary.setReadOnly(True)
        self.summary.setObjectName("logbox")
        self.summary.setPlainText("Seleccioná un snapshot de la lista o generá uno nuevo.")
        right_lay.addWidget(self.summary, 1)

        btnrow = QHBoxLayout()
        self.btn_open_file = QPushButton("Abrir JSON")
        self.btn_open_file.setObjectName("btn")
        self.btn_copy_path = QPushButton("Copiar ruta")
        self.btn_copy_path.setObjectName("btn")

        btnrow.addWidget(self.btn_open_file)
        btnrow.addWidget(self.btn_copy_path)
        btnrow.addStretch(1)
        right_lay.addLayout(btnrow)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 4)

        root.addWidget(splitter, 1)

        self.worker: SnapshotWorker | None = None
        self._selected_path = ""

        # events
        self.btn_run.clicked.connect(self.generate_snapshot)
        self.btn_refresh.clicked.connect(self.refresh_list)
        self.btn_open_dir.clicked.connect(self.open_snapshots_dir)
        self.btn_open_file.clicked.connect(self.open_selected_file)
        self.btn_copy_path.clicked.connect(self.copy_selected_path)
        self.table.selectionModel().selectionChanged.connect(self.on_selected)

        self.refresh_list()

    def set_status(self, msg: str):
        self.status.setText(f"Estado: {msg}")

    def open_snapshots_dir(self):
        try:
            d = get_snapshots_dir()
            os.startfile(str(d))  # type: ignore[attr-defined]
        except Exception as e:
            QMessageBox.warning(self, "Snapshot", f"No pude abrir la carpeta.\n{e}")

    def refresh_list(self):
        rows = []
        for p in list_snapshots():
            try:
                data = load_snapshot(p)
                summary = data.get("summary") or {}
                created = (summary.get("created_utc") or data.get("meta", {}).get("created_utc") or "")
                host = summary.get("hostname") or data.get("meta", {}).get("hostname") or ""
                os_str = summary.get("os") or (data.get("system") or {}).get("windows") or ""

                counts = summary.get("counts") or {}
                proc = counts.get("processes")
                conn = counts.get("connections")

                if proc is None:
                    proc = len(data.get("processes") or [])
                if conn is None:
                    conn = len(data.get("connections") or [])

                rows.append(
                    {
                        "created_utc": created,
                        "hostname": host,
                        "os": os_str,
                        "proc": proc,
                        "conn": conn,
                        "file": p.name,
                        "path": str(p),
                    }
                )
            except Exception:
                rows.append(
                    {
                        "created_utc": "",
                        "hostname": "",
                        "os": "",
                        "proc": "?",
                        "conn": "?",
                        "file": p.name,
                        "path": str(p),
                    }
                )

        self.model.set_rows(rows)
        self.set_status(f"{len(rows)} snapshots")

        if rows:
            self.table.selectRow(0)

    def on_selected(self, *_):
        idxs = self.table.selectionModel().selectedRows()
        if not idxs:
            self._selected_path = ""
            return
        row = idxs[0].row()
        path = self.model.row_path(row)
        self._selected_path = path
        self.load_and_render(path)

    def load_and_render(self, path: str):
        try:
            data = load_snapshot(path)
            txt = summary_to_text(data)
            self.summary.setPlainText(txt)
        except Exception as e:
            self.summary.setPlainText(f"No pude leer el snapshot.\n{e}")

    def open_selected_file(self):
        if not self._selected_path:
            return
        try:
            os.startfile(self._selected_path)  # type: ignore[attr-defined]
        except Exception as e:
            QMessageBox.warning(self, "Snapshot", f"No pude abrir el archivo.\n{e}")

    def copy_selected_path(self):
        if not self._selected_path:
            return
        try:
            QApplication.clipboard().setText(self._selected_path)
            self.set_status("ruta copiada")
        except Exception:
            pass

    def generate_snapshot(self):
        if self.worker and self.worker.isRunning():
            return

        self.btn_run.setEnabled(False)
        self.btn_refresh.setEnabled(False)
        self.set_status("generando...")
        self.summary.setPlainText("Generando snapshot...\nEsto puede tardar (hash + firmas + eventos).")

        self.worker = SnapshotWorker(max_events=20)
        self.worker.progress.connect(self.set_status)
        self.worker.result.connect(self.on_worker_result)
        self.worker.error.connect(self.on_worker_error)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.start()

    def on_worker_result(self, payload: dict):
        json_path = payload.get("json_path", "")
        sha_path = payload.get("sha256_path", "")
        file_hash = payload.get("file_sha256", "")

        snap = payload.get("snapshot") or {}
        txt = summary_to_text(snap)
        extra = []
        if json_path:
            extra.append(f"\nJSON: {json_path}")
        if sha_path:
            extra.append(f"SHA256: {sha_path}")
        if file_hash:
            extra.append(f"File SHA256: {file_hash}")

        self.summary.setPlainText(txt + "\n" + "\n".join(extra) + "\n")
        self.set_status("snapshot guardado")

        self.refresh_list()

        if json_path:
            for r, row in enumerate(self.model.rows):
                if row.get("path") == json_path:
                    self.table.selectRow(r)
                    break

    def on_worker_error(self, msg: str):
        QMessageBox.critical(self, "Snapshot", f"Falló el snapshot.\n{msg}")
        self.set_status("error")

    def on_worker_finished(self):
        self.btn_run.setEnabled(True)
        self.btn_refresh.setEnabled(True)
