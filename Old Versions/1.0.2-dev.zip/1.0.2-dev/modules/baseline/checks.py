import os
import json
import socket
import getpass
import platform
import subprocess
from datetime import datetime, timezone
import psutil
import os
import subprocess

def _no_console_kwargs():
    if os.name != "nt":
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0  # SW_HIDE
    return {"startupinfo": si, "creationflags": subprocess.CREATE_NO_WINDOW}


try:
    import winreg  # type: ignore
except Exception:
    winreg = None

from .scorer import compute_score

SCHEMA_ID = "sentineldesk.baseline.v1"


def _iso_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _run_ps_json(script: str, timeout: int = 60):
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            **_no_console_kwargs()
        )
        if proc.returncode != 0:
            err = (proc.stderr or proc.stdout or "").strip()
            return None, err or f"powershell_failed: code={proc.returncode}"
        out = (proc.stdout or "").strip()
        if not out:
            return None, "powershell_no_output"
        return json.loads(out), None
    except subprocess.TimeoutExpired:
        return None, "powershell_timeout"
    except Exception as e:
        return None, f"powershell_error: {e}"


def _win_version_string() -> str:
    if winreg is None:
        return f"{platform.system()} {platform.release()}"
    out = {}
    try:
        key_path = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as k:
            for name in ("ProductName", "DisplayVersion", "ReleaseId", "CurrentBuild", "UBR"):
                try:
                    v, _t = winreg.QueryValueEx(k, name)
                    out[name] = v
                except Exception:
                    pass
    except Exception:
        pass
    prod = out.get("ProductName") or "Windows"
    ver = out.get("DisplayVersion") or out.get("ReleaseId") or ""
    build = out.get("CurrentBuild")
    ubr = out.get("UBR")
    s = f"{prod} {ver}".strip()
    if build and ubr is not None:
        s += f" (Build {build}.{ubr})"
    elif build:
        s += f" (Build {build})"
    return s


def _finding(severity: str, title: str, details: str = "", recommendation: str = "", evidence=None):
    return {
        "severity": severity,  # High/Medium/Low/Info
        "title": title,
        "details": details,
        "recommendation": recommendation,
        "evidence": evidence or {},
    }


def check_firewall(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: firewall...")

    script = r'''
$profiles = Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction
$rules = Get-NetFirewallRule -Enabled True | Select-Object DisplayName, Direction, Action, Profile, Enabled
[pscustomobject]@{
  profiles = $profiles
  rules = $rules
} | ConvertTo-Json -Depth 4
'''
    data, err = _run_ps_json(script, timeout=120)
    findings = []
    evidence = {"error": err} if err else {"data": data}

    if err or not data:
        findings.append(_finding("Medium", "No se pudo leer el estado del Firewall", str(err), "Ejecutar como admin y verificar NetSecurity module.", evidence))
        return findings, evidence

    profiles = data.get("profiles") or []
    if isinstance(profiles, dict):
        profiles = [profiles]

    disabled = [p for p in profiles if str(p.get("Enabled")).lower() == "false"]
    if disabled:
        names = ", ".join([str(p.get("Name")) for p in disabled])
        findings.append(_finding(
            "High",
            "Firewall desactivado en uno o más perfiles",
            f"Perfiles desactivados: {names}",
            "Activar Firewall en Domain/Private/Public.",
            {"disabled_profiles": disabled},
        ))
    else:
        findings.append(_finding("Info", "Firewall activo en todos los perfiles", "OK", "", {"profiles": profiles}))

    # Reglas sospechosas (heurística simple)
    # Busco reglas Enabled con Action Allow + Direction Inbound y Profile incluye Public.
    rules = data.get("rules") or []
    if isinstance(rules, dict):
        rules = [rules]
    suspicious = []
    for r in rules:
        if not isinstance(r, dict):
            continue
        if str(r.get("Action")).lower() != "allow":
            continue
        if str(r.get("Direction")).lower() != "inbound":
            continue
        prof = str(r.get("Profile") or "")
        if "Public" in prof or "Any" in prof:
            suspicious.append(r)
    if suspicious:
        findings.append(_finding(
            "Medium",
            "Reglas inbound Allow con perfil Public/Any detectadas",
            f"Cantidad: {len(suspicious)} (heurística)",
            "Revisar reglas firewall inbound Allow especialmente en perfil Public.",
            {"sample": suspicious[:20]},
        ))

    return findings, evidence


def check_defender(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: windows defender...")

    script = r'''
$st = $null
$pref = $null
try { $st = Get-MpComputerStatus } catch { $st = [pscustomobject]@{ error = "$($_.Exception.Message)" } }
try { $pref = Get-MpPreference } catch { $pref = [pscustomobject]@{ error = "$($_.Exception.Message)" } }

[pscustomobject]@{
  status = $st
  preference = $pref
} | ConvertTo-Json -Depth 6
'''
    data, err = _run_ps_json(script, timeout=120)
    findings = []
    evidence = {"error": err} if err else {"data": data}

    if err or not data:
        findings.append(_finding("Medium", "No se pudo consultar Windows Defender", str(err), "Ejecutar como admin o verificar cmdlets de Defender.", evidence))
        return findings, evidence

    st = data.get("status") or {}
    if isinstance(st, dict) and st.get("error"):
        findings.append(_finding("Medium", "No se pudo leer Get-MpComputerStatus", str(st.get("error")), "Verificar que Microsoft Defender esté disponible.", {"status_error": st}))
        return findings, evidence

    def _b(k): return bool(st.get(k)) if k in st else None

    av = _b("AntivirusEnabled")
    rt = _b("RealTimeProtectionEnabled")

    if av is False:
        findings.append(_finding("High", "Defender antivirus desactivado", "AntivirusEnabled=False", "Activar Microsoft Defender o una solución AV equivalente.", {"status": st}))
    elif av is True:
        findings.append(_finding("Info", "Defender antivirus activo", "OK", "", {"status": st}))

    if rt is False:
        findings.append(_finding("High", "Protección en tiempo real desactivada", "RealTimeProtectionEnabled=False", "Habilitar real-time protection.", {"status": st}))
    elif rt is True:
        findings.append(_finding("Info", "Protección en tiempo real activa", "OK", "", {"status": st}))

    pref = data.get("preference") or {}
    if isinstance(pref, dict) and pref.get("error"):
        findings.append(_finding("Low", "No se pudo leer exclusiones de Defender", str(pref.get("error")), "Ejecutar como admin.", {"pref_error": pref}))
        return findings, evidence

    # Exclusiones
    ex_paths = pref.get("ExclusionPath") or []
    ex_procs = pref.get("ExclusionProcess") or []
    ex_ext = pref.get("ExclusionExtension") or []

    risky = []
    for p in ex_paths if isinstance(ex_paths, list) else [ex_paths]:
        if not p:
            continue
        s = str(p).lower()
        if s in ("c:\\", "c:", "\\"):
            risky.append(p)
        if s.startswith("c:\\users\\") and ("\\downloads" in s or "\\desktop" in s):
            risky.append(p)

    if risky:
        findings.append(_finding(
            "High",
            "Exclusiones de Defender potencialmente riesgosas",
            f"Exclusiones destacadas: {risky[:10]}",
            "Revisar y eliminar exclusiones amplias o en paths de ejecución común (Downloads/Desktop/Temp).",
            {"exclusion_path": ex_paths, "exclusion_process": ex_procs, "exclusion_extension": ex_ext},
        ))
    elif ex_paths or ex_procs or ex_ext:
        findings.append(_finding(
            "Medium",
            "Exclusiones de Defender configuradas",
            "Hay exclusiones definidas (revisar si están justificadas).",
            "Verificar que las exclusiones sean mínimas y justificadas.",
            {"exclusion_path": ex_paths, "exclusion_process": ex_procs, "exclusion_extension": ex_ext},
        ))
    else:
        findings.append(_finding("Info", "Sin exclusiones de Defender detectadas", "OK", "", {}))

    return findings, evidence


def check_uac(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: UAC...")

    findings = []
    evidence = {}

    if winreg is None:
        findings.append(_finding("Medium", "No se pudo leer UAC (winreg no disponible)", "", "Ejecutar en Windows.", {}))
        return findings, evidence

    path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    values = {}
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path) as k:
            for name in ("EnableLUA", "ConsentPromptBehaviorAdmin", "PromptOnSecureDesktop"):
                try:
                    v, _t = winreg.QueryValueEx(k, name)
                    values[name] = v
                except Exception:
                    pass
    except Exception as e:
        findings.append(_finding("Medium", "No se pudo leer configuración UAC", str(e), "Ejecutar como admin.", {}))
        return findings, evidence

    enable = values.get("EnableLUA")
    if enable == 0:
        findings.append(_finding("High", "UAC desactivado", f"EnableLUA={enable}", "Activar UAC (EnableLUA=1) y reiniciar.", {"registry": values}))
    elif enable == 1:
        findings.append(_finding("Info", "UAC activo", "OK", "", {"registry": values}))
    else:
        findings.append(_finding("Low", "UAC: estado desconocido", f"EnableLUA={enable}", "Revisar políticas UAC.", {"registry": values}))

    return findings, evidence


def check_secure_boot(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: secure boot...")

    script = r'''
try {
  $v = Confirm-SecureBootUEFI
  [pscustomobject]@{ supported=$true; enabled=$v }
} catch {
  [pscustomobject]@{ supported=$false; enabled=$null; error="$($_.Exception.Message)" }
} | ConvertTo-Json -Depth 3
'''
    data, err = _run_ps_json(script, timeout=30)
    findings = []
    evidence = {"error": err} if err else {"data": data}

    if err or not data:
        findings.append(_finding("Low", "No se pudo evaluar Secure Boot", str(err), "Verificar UEFI/SecureBoot desde BIOS o ejecutar como admin.", evidence))
        return findings, evidence

    if data.get("supported") is False:
        findings.append(_finding("Low", "Secure Boot no soportado o no accesible", str(data.get("error") or ""), "Si el equipo usa BIOS legacy, no aplica. Si es UEFI, revisar permisos.", data))
        return findings, evidence

    if data.get("enabled") is True:
        findings.append(_finding("Info", "Secure Boot activado", "OK", "", data))
    elif data.get("enabled") is False:
        findings.append(_finding("Medium", "Secure Boot desactivado", "enabled=False", "Activar Secure Boot en BIOS/UEFI (si aplica).", data))
    else:
        findings.append(_finding("Low", "Secure Boot: estado desconocido", "", "Revisar BIOS/UEFI.", data))

    return findings, evidence


def check_bitlocker(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: bitlocker...")

    script = r'''
try {
  $vols = Get-BitLockerVolume | Select-Object MountPoint, VolumeType, ProtectionStatus, LockStatus, EncryptionPercentage, KeyProtector
  $vols | ConvertTo-Json -Depth 6
} catch {
  [pscustomobject]@{ error="$($_.Exception.Message)" } | ConvertTo-Json -Depth 3
}
'''
    data, err = _run_ps_json(script, timeout=60)
    findings = []
    evidence = {"error": err} if err else {"data": data}

    if err or data is None:
        findings.append(_finding("Low", "No se pudo evaluar BitLocker", str(err), "Ejecutar como admin. En ediciones Home puede no aplicar.", evidence))
        return findings, evidence

    if isinstance(data, dict) and data.get("error"):
        findings.append(_finding("Low", "BitLocker no disponible o sin permisos", str(data.get("error")), "Si es Windows Home o sin BitLocker, no aplica.", data))
        return findings, evidence

    vols = data if isinstance(data, list) else ([data] if isinstance(data, dict) else [])
    os_drive = None
    for v in vols:
        if str(v.get("VolumeType") or "").lower() == "operatingsystem":
            os_drive = v
            break

    if not os_drive:
        findings.append(_finding("Low", "No se encontró volumen OS para BitLocker", "", "Verificar Get-BitLockerVolume.", {"volumes": vols}))
        return findings, evidence

    prot = os_drive.get("ProtectionStatus")
    # ProtectionStatus: On/Off (a veces 1/0 o strings)
    prot_str = str(prot).lower()
    on = prot_str in ("on", "1", "true")

    if on:
        findings.append(_finding("Info", "BitLocker activo en disco del sistema", "OK", "", {"os_volume": os_drive}))
    else:
        findings.append(_finding("Medium", "BitLocker no activo en disco del sistema", f"ProtectionStatus={prot}", "Activar cifrado del disco del sistema si aplica.", {"os_volume": os_drive}))

    return findings, evidence


def check_critical_services(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: servicios críticos...")

    critical = {
        "WinDefend": "Microsoft Defender Antivirus Service",
        "SecurityHealthService": "Windows Security Service",
        "wuauserv": "Windows Update",
        "EventLog": "Windows Event Log",
    }

    findings = []
    evidence = {}

    for name, label in critical.items():
        try:
            svc = psutil.win_service_get(name).as_dict()
            status = str(svc.get("status") or "").lower()
            start_type = str(svc.get("start_type") or "").lower()
            evidence[name] = {"status": status, "start_type": start_type, "display": label}

            if status != "running":
                findings.append(_finding("Medium", f"Servicio crítico no está corriendo: {label}", f"{name} status={status}", "Revisar por qué está detenido (política, AV tercero, deshabilitado).", {"service": svc}))
            if start_type in ("disabled",):
                findings.append(_finding("High", f"Servicio crítico deshabilitado: {label}", f"{name} start_type={start_type}", "Habilitar el servicio si corresponde.", {"service": svc}))
        except Exception as e:
            findings.append(_finding("Low", f"No se pudo leer servicio: {label}", str(e), "Ejecutar como admin.", {"service_name": name}))

    return findings, evidence


def check_password_policy(progress_cb=None):
    if progress_cb:
        progress_cb("baseline: políticas (contraseña/bloqueo)...")

    findings = []
    evidence = {}

    # net accounts (simple y confiable)
    try:
        proc = subprocess.run(
    ["cmd", "/c", "net accounts"],
    capture_output=True,
    text=True,
    timeout=15,
    **_no_console_kwargs()
    )
        text = (proc.stdout or "") + "\n" + (proc.stderr or "")
        evidence["net_accounts_raw"] = text.strip()
    except Exception as e:
        findings.append(_finding("Low", "No se pudo leer 'net accounts'", str(e), "Ejecutar cmd/net accounts manualmente.", {}))
        return findings, evidence

    raw = evidence.get("net_accounts_raw", "")

    # Heurísticas por parsing (no perfecto, pero útil)
    # Buscamos "Minimum password length" y "Lockout threshold" etc en inglés/español.
    def pick(keys):
        for k in keys:
            if k in raw:
                return k
        return None

    # Longitud mínima
    min_len = None
    for k in ("Minimum password length", "Longitud mínima de la contraseña"):
        if k in raw:
            # siguiente token numérico en la línea
            for line in raw.splitlines():
                if k in line:
                    nums = [int(s) for s in line.split() if s.isdigit()]
                    if nums:
                        min_len = nums[-1]
                    break

    if min_len is not None and min_len < 10:
        findings.append(_finding("Medium", "Contraseña mínima débil", f"Min length={min_len}", "Subir mínimo a 10-12+ si aplica.", {"min_length": min_len}))
    elif min_len is not None:
        findings.append(_finding("Info", "Contraseña mínima OK (heurística)", f"Min length={min_len}", "", {"min_length": min_len}))
    else:
        findings.append(_finding("Low", "No se pudo detectar longitud mínima de contraseña", "Parsing no concluyente", "Revisar políticas local/secpol.msc si aplica.", {}))

    return findings, evidence


def evaluate_baseline(progress_cb=None) -> dict:
    warnings = []
    errors = []

    system = {
        "windows": _win_version_string(),
        "hostname": socket.gethostname(),
        "user": getpass.getuser(),
        "architecture": platform.machine(),
    }

    meta = {
        "schema": SCHEMA_ID,
        "tool": "SentinelDesk",
        "module": "baseline",
        "build": "1.0.2-unstable",
        "created_utc": _iso_utc(),
        "hostname": system["hostname"],
        "user": system["user"],
    }

    all_findings = []
    evidence = {}

    for fn in (check_firewall, check_defender, check_uac, check_secure_boot, check_bitlocker, check_critical_services, check_password_policy):
        try:
            f, ev = fn(progress_cb=progress_cb)
            all_findings.extend(f)
            evidence[fn.__name__] = ev
        except Exception as e:
            errors.append(f"{fn.__name__}_error: {e}")

    score = compute_score(all_findings)

    # Ordenar hallazgos: High -> Medium -> Low -> Info
    order = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}
    all_findings.sort(key=lambda x: order.get(str(x.get("severity")), 9))

    return {
        "meta": meta,
        "system": system,
        "score": score,
        "findings": all_findings,
        "evidence": evidence,  # puedes ocultarlo en UI si no querés mostrarlo todo
        "warnings": warnings,
        "errors": errors,
    }
