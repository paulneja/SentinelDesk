import os
from pathlib import Path

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QTableView,
    QMessageBox,
    QSplitter,
    QHeaderView,
    QApplication,
)

from .worker import BaselineWorker
from .report import list_baselines, load_baseline, summary_to_text, get_reports_dir


class BaselineIndexModel(QAbstractTableModel):
    COLS = [
        ("Fecha (UTC)", "created_utc"),
        ("Host", "hostname"),
        ("Score", "score"),
        ("Riesgo", "risk"),
        ("High", "high"),
        ("Archivo", "file"),
    ]

    def __init__(self):
        super().__init__()
        self.rows: list[dict] = []

    def rowCount(self, parent=QModelIndex()):
        return len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(self.COLS)

    def headerData(self, section, orientation, role):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return self.COLS[section][0]
        return str(section + 1)

    def data(self, index: QModelIndex, role: int):
        if not index.isValid():
            return None
        r = self.rows[index.row()]
        key = self.COLS[index.column()][1]

        if role == Qt.DisplayRole:
            return str(r.get(key, ""))

        if role == Qt.TextAlignmentRole:
            if key in ("score", "high"):
                return int(Qt.AlignCenter)
            return int(Qt.AlignLeft | Qt.AlignVCenter)

        return None

    def set_rows(self, rows: list[dict]):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def row_path(self, row: int) -> str:
        if row < 0 or row >= len(self.rows):
            return ""
        return self.rows[row].get("path", "")


class BaselinePage(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        title = QLabel("Security Baseline Checker")
        title.setFont(QFont("Segoe UI", 15, QFont.Bold))
        title.setObjectName("pagetitle")

        subtitle = QLabel(
            "Evalúa postura de seguridad sin modificar nada. Genera JSON y permite revisar reportes previos."
        )
        subtitle.setWordWrap(True)
        subtitle.setObjectName("muted")

        root.addWidget(title)
        root.addWidget(subtitle)

        controls = QFrame()
        controls.setObjectName("panel")
        c = QHBoxLayout(controls)
        c.setContentsMargins(12, 10, 12, 10)
        c.setSpacing(10)

        self.btn_run = QPushButton("Ejecutar baseline")
        self.btn_run.setObjectName("btn")

        self.btn_refresh = QPushButton("Refrescar")
        self.btn_refresh.setObjectName("btn")

        self.btn_open_dir = QPushButton("Abrir carpeta reportes")
        self.btn_open_dir.setObjectName("btn")

        self.status = QLabel("Estado: listo")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)

        c.addWidget(self.btn_run)
        c.addWidget(self.btn_refresh)
        c.addWidget(self.btn_open_dir)
        c.addStretch(1)
        c.addWidget(self.status)

        root.addWidget(controls)

        splitter = QSplitter(Qt.Horizontal)

        left = QFrame()
        left.setObjectName("panel")
        ll = QVBoxLayout(left)
        ll.setContentsMargins(12, 12, 12, 12)
        ll.setSpacing(8)

        ll.addWidget(QLabel("Reportes guardados"))

        self.table = QTableView()
        self.model = BaselineIndexModel()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setStretchLastSection(True)

        ll.addWidget(self.table)

        right = QFrame()
        right.setObjectName("panel")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(12, 12, 12, 12)
        rl.setSpacing(8)

        rl.addWidget(QLabel("Resumen"))

        self.summary = QTextEdit()
        self.summary.setReadOnly(True)
        self.summary.setObjectName("logbox")
        self.summary.setPlainText("Seleccioná un reporte o ejecutá un baseline nuevo.")
        rl.addWidget(self.summary, 1)

        btnrow = QHBoxLayout()
        self.btn_open_file = QPushButton("Abrir JSON")
        self.btn_open_file.setObjectName("btn")
        self.btn_copy_path = QPushButton("Copiar ruta")
        self.btn_copy_path.setObjectName("btn")

        btnrow.addWidget(self.btn_open_file)
        btnrow.addWidget(self.btn_copy_path)
        btnrow.addStretch(1)
        rl.addLayout(btnrow)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 4)

        root.addWidget(splitter, 1)

        self.worker: BaselineWorker | None = None
        self._selected_path = ""

        self.btn_run.clicked.connect(self.run_baseline)
        self.btn_refresh.clicked.connect(self.refresh_list)
        self.btn_open_dir.clicked.connect(self.open_reports_dir)
        self.btn_open_file.clicked.connect(self.open_selected_file)
        self.btn_copy_path.clicked.connect(self.copy_selected_path)
        self.table.selectionModel().selectionChanged.connect(self.on_selected)

        self.refresh_list()

    def set_status(self, msg: str):
        self.status.setText(f"Estado: {msg}")

    def open_reports_dir(self):
        try:
            d = get_reports_dir()
            os.startfile(str(d))  # type: ignore[attr-defined]
        except Exception as e:
            QMessageBox.warning(self, "Baseline", f"No pude abrir la carpeta.\n{e}")

    def refresh_list(self):
        rows = []
        for p in list_baselines():
            try:
                data = load_baseline(p)
                summary = data.get("summary") or {}
                created = summary.get("created_utc") or (data.get("meta") or {}).get("created_utc") or ""
                host = summary.get("hostname") or (data.get("meta") or {}).get("hostname") or ""
                score = summary.get("score") or (data.get("score") or {}).get("value")
                risk = summary.get("risk_level") or (data.get("score") or {}).get("risk_level")

                sev = summary.get("severity_counts") or {}
                high = sev.get("High", 0)

                rows.append({
                    "created_utc": created,
                    "hostname": host,
                    "score": score,
                    "risk": risk,
                    "high": high,
                    "file": p.name,
                    "path": str(p),
                })
            except Exception:
                rows.append({
                    "created_utc": "",
                    "hostname": "",
                    "score": "?",
                    "risk": "?",
                    "high": "?",
                    "file": p.name,
                    "path": str(p),
                })

        self.model.set_rows(rows)
        self.set_status(f"{len(rows)} reportes")
        if rows:
            self.table.selectRow(0)

    def on_selected(self, *_):
        idxs = self.table.selectionModel().selectedRows()
        if not idxs:
            self._selected_path = ""
            return
        row = idxs[0].row()
        path = self.model.row_path(row)
        self._selected_path = path
        self.load_and_render(path)

    def load_and_render(self, path: str):
        try:
            data = load_baseline(path)
            self.summary.setPlainText(summary_to_text(data))
        except Exception as e:
            self.summary.setPlainText(f"No pude leer el reporte.\n{e}")

    def open_selected_file(self):
        if not self._selected_path:
            return
        try:
            os.startfile(self._selected_path)  # type: ignore[attr-defined]
        except Exception as e:
            QMessageBox.warning(self, "Baseline", f"No pude abrir el archivo.\n{e}")

    def copy_selected_path(self):
        if not self._selected_path:
            return
        try:
            QApplication.clipboard().setText(self._selected_path)
            self.set_status("ruta copiada")
        except Exception:
            pass

    def run_baseline(self):
        if self.worker and self.worker.isRunning():
            return

        self.btn_run.setEnabled(False)
        self.btn_refresh.setEnabled(False)
        self.set_status("ejecutando...")
        self.summary.setPlainText("Ejecutando baseline...\nEsto puede tardar (cmdlets + políticas + servicios).")

        self.worker = BaselineWorker()
        self.worker.progress.connect(self.set_status)
        self.worker.result.connect(self.on_worker_result)
        self.worker.error.connect(self.on_worker_error)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.start()

    def on_worker_result(self, payload: dict):
        json_path = payload.get("json_path", "")
        sha_path = payload.get("sha256_path", "")
        file_hash = payload.get("file_sha256", "")

        report = payload.get("report") or {}
        txt = summary_to_text(report)

        extra = []
        if json_path:
            extra.append(f"\nJSON: {json_path}")
        if sha_path:
            extra.append(f"SHA256: {sha_path}")
        if file_hash:
            extra.append(f"File SHA256: {file_hash}")

        self.summary.setPlainText(txt + "\n" + "\n".join(extra) + "\n")
        self.set_status("reporte guardado")

        self.refresh_list()

        if json_path:
            for r, row in enumerate(self.model.rows):
                if row.get("path") == json_path:
                    self.table.selectRow(r)
                    break

    def on_worker_error(self, msg: str):
        QMessageBox.critical(self, "Baseline", f"Falló el baseline.\n{msg}")
        self.set_status("error")

    def on_worker_finished(self):
        self.btn_run.setEnabled(True)
        self.btn_refresh.setEnabled(True)
