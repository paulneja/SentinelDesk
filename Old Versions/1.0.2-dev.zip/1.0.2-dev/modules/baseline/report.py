import os
import sys
import json
import re
import hashlib
from pathlib import Path
from datetime import datetime, timezone

SCHEMA_ID = "sentineldesk.baseline.v1"


def _app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def get_reports_dir() -> Path:
    # Si querés carpeta dedicada, cambiá esto a:  _app_base_dir() / "baselines"
    d = _app_base_dir() / "snapshots"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _safe_name(s: str) -> str:
    s = s.strip().replace(" ", "_")
    s = re.sub(r"[^a-zA-Z0-9_\-\.]+", "_", s)
    return s[:80] if len(s) > 80 else s


def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_baseline(report: dict) -> dict:
    d = get_reports_dir()

    meta = report.setdefault("meta", {})
    meta.setdefault("schema", SCHEMA_ID)
    meta.setdefault("created_utc", datetime.now(timezone.utc).isoformat())

    hostname = meta.get("hostname") or "host"
    created = meta.get("created_utc") or datetime.now(timezone.utc).isoformat()

    try:
        dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
    except Exception:
        dt = datetime.now(timezone.utc)
    stamp = dt.strftime("%Y%m%d_%H%M%S")

    fname = f"baseline_{stamp}_{_safe_name(str(hostname))}.json"
    out = d / fname
    i = 1
    while out.exists():
        out = d / f"baseline_{stamp}_{_safe_name(str(hostname))}_{i}.json"
        i += 1

    canonical = json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    meta["content_sha256"] = _sha256_bytes(canonical)

    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    file_hash = _sha256_file(out)

    sha_path = out.with_suffix(".sha256")
    sha_path.write_text(f"{file_hash}  {out.name}\n", encoding="utf-8")

    return {
        "dir": str(d),
        "json_path": str(out),
        "sha256_path": str(sha_path),
        "file_sha256": file_hash,
    }


def list_baselines(limit: int = 200) -> list[Path]:
    d = get_reports_dir()
    files = sorted(d.glob("baseline_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[:limit]


def load_baseline(path: str | Path) -> dict:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    meta = data.get("meta") or {}
    if meta.get("schema") != SCHEMA_ID:
        data.setdefault("warnings", []).append("schema_mismatch: not a SentinelDesk baseline v1")
    return data


def build_summary(report: dict) -> dict:
    meta = report.get("meta") or {}
    score = report.get("score", {})
    findings = report.get("findings") or []

    sev = {"High": 0, "Medium": 0, "Low": 0, "Info": 0, "Unknown": 0}
    for f in findings:
        s = str((f or {}).get("severity") or "Unknown")
        if s not in sev:
            sev["Unknown"] += 1
        else:
            sev[s] += 1

    return {
        "created_utc": meta.get("created_utc"),
        "hostname": meta.get("hostname"),
        "os": (report.get("system") or {}).get("windows"),
        "score": score.get("value"),
        "risk_level": score.get("risk_level"),
        "severity_counts": sev,
        "findings_total": len(findings),
    }


def summary_to_text(report: dict) -> str:
    summary = report.get("summary") or build_summary(report)

    lines = []
    lines.append("SentinelDesk Security Baseline Report")
    lines.append("─────────────────────────────────────")
    lines.append(f"UTC:  {summary.get('created_utc')}")
    lines.append(f"Host: {summary.get('hostname')}")
    lines.append(f"OS:   {summary.get('os')}")
    lines.append("")
    lines.append(f"Score: {summary.get('score')}/100")
    lines.append(f"Riesgo: {summary.get('risk_level')}")
    lines.append("")

    sev = summary.get("severity_counts") or {}
    lines.append("Hallazgos por severidad")
    lines.append(f"- High:   {sev.get('High')}")
    lines.append(f"- Medium: {sev.get('Medium')}")
    lines.append(f"- Low:    {sev.get('Low')}")
    lines.append(f"- Info:   {sev.get('Info')}")
    lines.append("")

    lines.append("Hallazgos (top)")
    findings = report.get("findings") or []
    for f in findings[:15]:
        lines.append(f"- [{f.get('severity')}] {f.get('title')}")
        rec = f.get("recommendation")
        if rec:
            lines.append(f"  ↳ {rec}")
    if len(findings) > 15:
        lines.append(f"... +{len(findings) - 15} más")

    warns = report.get("warnings") or []
    errs = report.get("errors") or []
    if warns or errs:
        lines.append("")
        lines.append("Notas / Limitaciones")
        for w in warns[:20]:
            lines.append(f"- {w}")
        for e in errs[:20]:
            lines.append(f"- {e}")

    return "\n".join(lines)
