from PySide6.QtCore import QThread, Signal

from .checks import evaluate_baseline
from .report import save_baseline, build_summary


class BaselineWorker(QThread):
    progress = Signal(str)
    result = Signal(dict)
    error = Signal(str)

    def __init__(self):
        super().__init__()

    def run(self):
        try:
            report = evaluate_baseline(progress_cb=lambda m: self.progress.emit(m))
            # Summary for browser
            try:
                report["summary"] = build_summary(report)
            except Exception:
                report["summary"] = {}

            paths = save_baseline(report)

            self.result.emit({
                "report": report,
                **paths,
            })
        except Exception as e:
            self.error.emit(str(e))
