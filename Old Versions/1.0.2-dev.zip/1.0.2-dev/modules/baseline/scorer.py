def clamp(n: int, lo: int, hi: int) -> int:
    return lo if n < lo else hi if n > hi else n


def risk_level(score: int) -> str:
    if score >= 85:
        return "Bajo"
    if score >= 60:
        return "Medio"
    return "Alto"


def compute_score(findings: list[dict]) -> dict:
    """
    Arranca en 100 y resta según severidad.
    High   -12
    Medium -7
    Low    -3
    Info   -0
    """
    score = 100
    for f in findings:
        sev = str((f or {}).get("severity") or "Info")
        if sev == "High":
            score -= 12
        elif sev == "Medium":
            score -= 7
        elif sev == "Low":
            score -= 3
        else:
            score -= 0

    score = clamp(score, 0, 100)
    return {"value": score, "risk_level": risk_level(score)}
