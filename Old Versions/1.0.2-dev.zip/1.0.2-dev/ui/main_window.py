from pathlib import Path

from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget, QFrame, QLabel
)
from modules.files.page import FilesPage
from ui.topbar import TopBar
from ui.rightnav import RightNav
from modules.terminal.page import TerminalPage
from modules.snapshot.page import SnapshotPage
from modules.baseline.page import BaselinePage


from modules.logs.page import LogsPage
from modules.connections.page import ConnectionsPage
from modules.ports.page import PortsPage

APP_NAME = "SentinelDesk"


class PlaceholderPage(QWidget):
    def __init__(self, title: str, subtitle: str):
        super().__init__()

        from PySide6.QtWidgets import QScrollArea
        from PySide6.QtCore import Qt

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)

        container = QFrame()
        container.setObjectName("page")

        inner_layout = QVBoxLayout(container)
        inner_layout.setContentsMargins(18, 18, 18, 18)
        inner_layout.setSpacing(12)

        t = QLabel(title)
        t.setObjectName("pagetitle")
        t.setFont(QFont("Segoe UI", 18, QFont.Bold))

        s = QLabel(subtitle)
        s.setObjectName("pagesub")
        s.setWordWrap(True)
        s.setTextInteractionFlags(Qt.TextSelectableByMouse)

        inner_layout.addWidget(t)
        inner_layout.addWidget(s)
        inner_layout.addStretch(1)

        scroll.setWidget(container)
        main_layout.addWidget(scroll)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle(APP_NAME)
        self.resize(1350, 820)

        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(12)

        # Top bar
        self.top = TopBar(APP_NAME)
        root.addWidget(self.top)

        # Body
        body = QHBoxLayout()
        body.setSpacing(12)
        root.addLayout(body, 1)

        self.stack = QStackedWidget()

        self.nav = RightNav()
        self.nav.setFixedWidth(240)

        # Pages (order MUST match rightnav)
        self.page_dashboard = PlaceholderPage(
    "Dashboard",
"""SentinelDesk — Latest Build 1.0.2 (stable)

Bienvenido a SentinelDesk.

SentinelDesk es una herramienta de inspección y análisis local diseñada para ofrecer visibilidad técnica real sobre el estado del sistema, la actividad de red y la configuración de seguridad. No automatiza decisiones. No suaviza advertencias. Proporciona información estructurada y control técnico directo.

────────────────────────────────────────────

Versión actual: 1.0.2
Canal: Estable
Estado: Recomendada para uso regular

Esta build incorpora nuevos módulos estructurales en fase de validación. Pueden producirse cambios en el modelo de datos, sistema de puntuación o estructura interna sin previo aviso.

Novedades en 1.0.2:

Snapshot Engine
• Captura estructurada completa del estado del sistema
• Procesos con SHA256 y validación de firma digital
• Conexiones activas y remotas públicas
• Servicios, tareas programadas y persistencia básica
• Exportación JSON verificable
• Generación automática de resumen técnico

Security Baseline Checker
• Evaluación de postura de seguridad local
• Sistema de puntuación (0–100) con nivel de riesgo
• Hallazgos clasificados por severidad
• Evidencia técnica basada en CIM/WMI
• Recomendaciones accionables

Cambios menores:
• Mejoras en la interfaz de DASHBOARD
• Optimización de rendimiento en análisis de archivos
• Fue añadido un pequeño bloque en el dashbord sobre el futuro del proyecto con ideas en evaluación (no roadmap oficial)
• Corrección de bugs menores y optimizaciones internas
• Problema visual con las terminales (resuelto)

Datos Importantes:
• Para el correcto funcionamiento de algunos módulos, se recomienda ejecutar con privilegios elevados y tener Npcap instalado. En su defecto estara limitado a funcionalidades básicas sin acceso a ciertos datos del sistema.

SentinelDesk 1.0.2-dev (UNSTABLE) está activo.

© 2026 PN Security

────────────────────────────────────────────


────────────────────────────────────────────

Futuro del Proyecto (Ideas en Evaluación)

Las siguientes líneas representan posibles direcciones de evolución.
No constituyen roadmap oficial ni compromisos definidos.

• Exportación profesional de reportes (HTML/PDF)
• Comparación automática entre snapshots (baseline histórico)
• Administrador de reglas de firewall
• Nuevos módulos en desarrollo

Estas ideas se encuentran en análisis conceptual y pueden modificarse sin previo aviso.

────────────────────────────────────────────


────────────────────────────────────────────


SentinelDesk — Stable Build 1.0.1

Versión estable para uso regular.
Se recomienda actualizar a 1.0.2 para acceso a nuevas funcionalidades, aunque 1.0.1 sigue siendo una opción sólida y confiable.


Versión actual: 1.0.1
Canal: Estable/Obsoleta
Estado: Fuera de soporte.

Cambios introducidos en 1.0.1
• Eliminada la apertura visible de consola en procesos internos
• Mejora en la lectura de eventos del sistema
• Optimización del análisis de archivos
• Ajustes generales de estabilidad

(Mantener el bloque de módulos igual que ya lo tenías)

SentinelDesk 1.0.1 está activo.

© 2026 PN Security

────────────────────────────────────────────

SentinelDesk — Version 1.0.0 (OBSOLETA)

Versión: 1.0.0
Canal: Obsoleta

Estado: Obsoleta — Solo referencia histórica

Esta versión ha sido reemplazada por builds posteriores con mejoras de estabilidad y arquitectura.

Correcciones clave introducidas en 1.0.0 
• Eliminado crash por manejo incorrecto de eventos • Eliminado escaneo involuntario en motor Nmap 
• Optimización de threads y estabilidad UI 
• Corrección de imports en motor Nmap 
• Control persistente del Modo Inseguro 
• Eliminación de bloqueos por lectura masiva

Se recomienda actualizar.

────────────────────────────────────────────

© 2026 PN Security
"""

)
        self.page_snapshot = SnapshotPage()
        self.page_baseline = BaselinePage()
        self.page_logs = LogsPage()
        self.page_connections = ConnectionsPage()
        self.page_ports = PortsPage()
        self.page_files = FilesPage()
        self.page_terminal = TerminalPage()
        

        self.stack.addWidget(self.page_dashboard)    # 0
        self.stack.addWidget(self.page_snapshot)     # 1
        self.stack.addWidget(self.page_baseline)     # 2
        self.stack.addWidget(self.page_logs)         # 3
        self.stack.addWidget(self.page_connections)  # 4
        self.stack.addWidget(self.page_ports)        # 5
        self.stack.addWidget(self.page_files)        # 6
        self.stack.addWidget(self.page_terminal)     # 7

        body.addWidget(self.stack, 1)
        body.addWidget(self.nav)

        self.setCentralWidget(central)

        # Load theme
        qss = Path(__file__).resolve().parent / "theme.qss"
        if qss.exists():
            self.setStyleSheet(qss.read_text(encoding="utf-8"))

        # Navigation wiring
        self.nav.list.currentRowChanged.connect(self.stack.setCurrentIndex)
