from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QComboBox,
    QSpinBox, QDoubleSpinBox, QSplitter, QTableView, QTextEdit, QMessageBox,
    QFileDialog, QDialog, QDialogButtonBox
)

from modules.ports.utils import parse_ports, find_nmap_in_path
from modules.ports.worker import PortsWorker

# Persistente solo en sesión (se resetea al cerrar la app)
INSECURE_ACTIVE = False

COLS = ["Host", "Port", "State", "Service", "Confidence", "PID", "Process"]

class PortsModel(QAbstractTableModel):
    def __init__(self):
        super().__init__()
        self.rows = []

    def rowCount(self, parent=QModelIndex()):
        return len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return len(COLS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        return COLS[section] if orientation == Qt.Horizontal else str(section + 1)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        r = self.rows[index.row()]
        key = COLS[index.column()]
        if role == Qt.DisplayRole:
            return str(r.get(key, ""))
        return None

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def get(self, i):
        if 0 <= i < len(self.rows):
            return self.rows[i]
        return None


class InsecureDialog(QDialog):
    """
    3 CONFIRM.
    """
    def __init__(self, step: int):
        super().__init__()
        self.step = step
        self.setModal(True)
        self.setMinimumWidth(640)

        lay = QVBoxLayout(self)
        title = QLabel("UNSAFE MODE")
        title.setFont(QFont("Segoe UI", 13, QFont.Bold))
        title.setStyleSheet("color:#ff6b6b;")
        lay.addWidget(title)

        if step == 1:
            self.setWindowTitle("Warning 1/3")
            txt = (
                "This enables active scanning actions.\n\n"
                "In the case of use, even if it's a local network, you can:\n"
                "- Generate logs in security systems (IDS/Firewall)\n"
                "- Cause automatic blocks or IP restrictions\n"
                "- Be interpreted as hostile behavior and cause legal consequences/actions\n\n"
                "If you don't have explicit authorization, do not continue."
            )
        elif step == 2:
            self.setWindowTitle("Warning 2/3")
            txt = (
                "This mode is NOT for learning or playing.\n\n"
                "If you run commands 'just because', the program assumes that:\n"
                "- You understand exactly what you are doing\n"
                "- You accept technical and LEGAL consequences\n"
                "- You don't need anything simplified\n\n"
                "There are no presets. There are no aids and you accept total responsibility."
            )
        else:
            self.setWindowTitle("Warning 3/3")
            txt = (
                "Last confirmation.\n\n"
                "To enable UNSAFE MODE in this session:\n"
                "Write exactly: CONFIRM\n\n"
                "It will remain ACTIVE until you close the program."
            )

        msg = QLabel(txt)
        msg.setWordWrap(True)
        msg.setStyleSheet("color:#e9edf5;")
        lay.addWidget(msg)

        self.edit = None
        if step == 3:
            self.edit = QLineEdit()
            self.edit.setPlaceholderText("CONFIRM")
            lay.addWidget(self.edit)

        bb = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def confirmed(self) -> bool:
        if self.step != 3:
            return True
        return (self.edit.text().strip() if self.edit else "") == "CONFIRM"


class PortsPage(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.worker = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 18, 18, 18)
        outer.setSpacing(12)

        # Banner Unsafe Mode
        self.banner = QLabel("")
        self.banner.setVisible(False)
        self.banner.setStyleSheet(
            "padding:10px; border-radius:10px;"
            "background:#2b1010; color:#ff6b6b; font-weight:700;"
        )
        outer.addWidget(self.banner)

        title = QLabel("Ports")
        title.setObjectName("pagetitle")
        title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        outer.addWidget(title)

        sub = QLabel("TCP scan on localhost (localhost) with native engine or Nmap (only in Unsafe Mode).")
        sub.setObjectName("pagesub")
        sub.setWordWrap(True)
        outer.addWidget(sub)

        controls = QFrame()
        controls.setObjectName("panel")
        c = QHBoxLayout(controls)
        c.setContentsMargins(12, 12, 12, 12)
        c.setSpacing(10)

        # Target fixed for security: localhost (same as what you see with nmap)
        self.lbl_target = QLabel("Target: 127.0.0.1 (localhost)")
        self.lbl_target.setStyleSheet("color:#e9edf5;")

        # Ports: presets + custom
        self.cmb_ports = QComboBox()
        self.cmb_ports.addItems(["1-1024", "ALL TCP (1-65535)", "Custom…"])

        self.ed_ports = QLineEdit("1-1024")
        self.ed_ports.setPlaceholderText("Ex: 22,80,443 or 8000-8100")
        self.ed_ports.setVisible(False)

        # Engine: nmap does not appear until insecure is activated
        self.cmb_engine = QComboBox()
        self.cmb_engine.addItems(["NATIVE"])  # NMAP is added only when insecure is enabled

        # Native config (precise and configurable)
        self.spn_workers = QSpinBox()
        self.spn_workers.setRange(10, 1200)
        self.spn_workers.setValue(250)

        self.spn_connect = QDoubleSpinBox()
        self.spn_connect.setRange(0.05, 6.0)
        self.spn_connect.setDecimals(2)
        self.spn_connect.setValue(0.50)
        self.spn_connect.setSingleStep(0.05)

        self.spn_probe = QDoubleSpinBox()
        self.spn_probe.setRange(0.05, 10.0)
        self.spn_probe.setDecimals(2)
        self.spn_probe.setValue(1.10)
        self.spn_probe.setSingleStep(0.05)

        # Unsafe mode button
        self.btn_insecure = QPushButton("Activate Unsafe Mode")
        self.btn_insecure.clicked.connect(self.activate_insecure)

        self.btn_run = QPushButton("Scan")
        self.btn_run.clicked.connect(self.run)

        c.addWidget(self.lbl_target, 2)
        c.addWidget(QLabel("Ports:"))
        c.addWidget(self.cmb_ports)
        c.addWidget(self.ed_ports, 2)
        c.addWidget(QLabel("Engine:"))
        c.addWidget(self.cmb_engine)
        c.addWidget(QLabel("Workers:"))
        c.addWidget(self.spn_workers)
        c.addWidget(QLabel("Connect s:"))
        c.addWidget(self.spn_connect)
        c.addWidget(QLabel("Probe s:"))
        c.addWidget(self.spn_probe)
        c.addWidget(self.btn_insecure)
        c.addWidget(self.btn_run)

        outer.addWidget(controls)

        # Nmap Panel (only visible if engine NMAP)
        nmap_panel = QFrame()
        nmap_panel.setObjectName("panel")
        n = QHBoxLayout(nmap_panel)
        n.setContentsMargins(12, 12, 12, 12)
        n.setSpacing(10)

        self.ed_nmap = QLineEdit()
        self.ed_nmap.setPlaceholderText("Path to nmap.exe (or empty to search in PATH)")
        self.btn_pick = QPushButton("Choose…")
        self.btn_pick.clicked.connect(self.pick_nmap)

        self.ed_args = QLineEdit("-sV -p 1-1024 -oN -")
        self.ed_args.setPlaceholderText("IP + Arguments. Ex: 192.168.1.0 -sV -p 1-1024")

        self.lbl_pro = QLabel("NMAP — ONLY WITH EXPLICIT AUTHORIZATION.")
        self.lbl_pro.setStyleSheet("color:#ffb3b3; font-weight:700;")

        n.addWidget(self.lbl_pro, 2)
        n.addWidget(QLabel("nmap.exe:"))
        n.addWidget(self.ed_nmap, 2)
        n.addWidget(self.btn_pick)
        n.addWidget(QLabel("args:"))
        n.addWidget(self.ed_args, 3)

        outer.addWidget(nmap_panel)
        self.nmap_panel = nmap_panel
        self.nmap_panel.setVisible(False)

        self.lbl_status = QLabel("Ready.")
        self.lbl_status.setStyleSheet("color:#aab3c5;")
        outer.addWidget(self.lbl_status)

        split = QSplitter(Qt.Horizontal)

        left = QFrame()
        left.setObjectName("panel")
        l = QVBoxLayout(left)
        l.setContentsMargins(12, 12, 12, 12)
        l.setSpacing(10)

        self.model = PortsModel()
        self.table = QTableView()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.setSortingEnabled(True)
        self.table.clicked.connect(self.on_select)

        self.table.setColumnWidth(0, 140)
        self.table.setColumnWidth(1, 80)
        self.table.setColumnWidth(2, 90)
        self.table.setColumnWidth(3, 180)
        self.table.setColumnWidth(4, 120)
        self.table.setColumnWidth(5, 80)
        self.table.setColumnWidth(6, 260)

        l.addWidget(self.table, 1)
        split.addWidget(left)

        right = QFrame()
        right.setObjectName("panel")
        r = QVBoxLayout(right)
        r.setContentsMargins(12, 12, 12, 12)
        r.setSpacing(10)

        head = QLabel("Detail")
        head.setFont(QFont("Segoe UI", 12, QFont.Bold))
        head.setStyleSheet("color:#e9edf5;")
        r.addWidget(head)

        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        r.addWidget(self.detail, 1)

        self.nmap_out = QTextEdit()
        self.nmap_out.setReadOnly(True)
        self.nmap_out.setPlaceholderText("Raw scan output.")
        r.addWidget(self.nmap_out, 1)

        split.addWidget(right)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)

        outer.addWidget(split, 1)

        # hooks UI
        self.cmb_ports.currentIndexChanged.connect(self.sync_ports_ui)
        self.cmb_engine.currentIndexChanged.connect(self.sync_engine_ui)
        self.sync_ports_ui()
        self.sync_engine_ui()
        self.refresh_insecure_ui()

    def sync_ports_ui(self):
        mode = self.cmb_ports.currentText()
        is_custom = mode.startswith("Custom")
        self.ed_ports.setVisible(is_custom)

        if not is_custom:
            if mode.startswith("1-1024"):
                self.ed_ports.setText("1-1024")
            else:
                self.ed_ports.setText("1-65535")

    def sync_engine_ui(self):
        eng = self.cmb_engine.currentText()
        self.nmap_panel.setVisible(eng == "NMAP")
        # si es nmap, no tiene sentido workers/connect/probe (eso lo maneja nmap)
        is_nmap = (eng == "NMAP")
        self.spn_workers.setEnabled(not is_nmap)
        self.spn_connect.setEnabled(not is_nmap)
        self.spn_probe.setEnabled(not is_nmap)

    def refresh_insecure_ui(self):
        global INSECURE_ACTIVE

        if INSECURE_ACTIVE:
            self.banner.setText("UNSAFE MODE ACTIVE")
            self.banner.setVisible(True)
            self.btn_insecure.setEnabled(False)

            # habilitar NMAP en selector si todavía no existe
            if self.cmb_engine.findText("NMAP") == -1:
                self.cmb_engine.addItem("NMAP")

            # autocompletar ruta nmap si está en PATH
            if not self.ed_nmap.text().strip():
                p = find_nmap_in_path()
                if p:
                    self.ed_nmap.setText(p)
        else:
            self.banner.setVisible(False)
            self.btn_insecure.setEnabled(True)

            # ocultar NMAP totalmente
            idx = self.cmb_engine.findText("NMAP")
            if idx != -1:
                # si estaba seleccionado, volver a NATIVE
                if self.cmb_engine.currentText() == "NMAP":
                    self.cmb_engine.setCurrentText("NATIVE")
                self.cmb_engine.removeItem(idx)

        self.sync_engine_ui()

    def activate_insecure(self):
        global INSECURE_ACTIVE
        if INSECURE_ACTIVE:
            return

        d1 = InsecureDialog(1)
        if d1.exec() != QDialog.Accepted:
            return

        d2 = InsecureDialog(2)
        if d2.exec() != QDialog.Accepted:
            return

        d3 = InsecureDialog(3)
        if d3.exec() != QDialog.Accepted or not d3.confirmed():
            QMessageBox.warning(self, "Unsafe Mode", "Not confirmed. Unsafe Mode NOT activated.")
            return

        INSECURE_ACTIVE = True
        self.refresh_insecure_ui()
        self.lbl_status.setText("Unsafe Mode activated (persistent until restart).")
        QMessageBox.critical(
    self,
    "UNSAFE MODE ACTIVATED",
    "Welcome to UNSAFE MODE.\n\n"
    "Active scanning with Nmap has been enabled.\n\n"
    "You can now execute scans on user-defined targets.\n"
    "These scans may generate visible traffic, logs in remote systems\n"
    "and automatic alerts in protected infrastructures.\n\n"
    "To unlock full potential:\n"
    "• Run SentinelDesk as Administrator.\n"
    "• Ensure Npcap is properly installed.\n\n"
    "Without elevated privileges or without Npcap, certain advanced capabilities\n"
    "(SYN scan, OS detection, specific NSE functions)\n"
    "will not be available.\n\n"
    "All responsibility derived from the use of this mode falls exclusively on the user.\n\n"
    "Use it at your own risk."
)

    def pick_nmap(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select nmap.exe", "", "nmap.exe (nmap.exe)")
        if f:
            self.ed_nmap.setText(f)

    def run(self):
        if self.worker and self.worker.isRunning():
            return

        global INSECURE_ACTIVE

        engine = self.cmb_engine.currentText()  # NATIVE / NMAP
        ports_text = self.ed_ports.text().strip()
        ports = parse_ports(ports_text)

        # Gate duro: NMAP solo si inseguro activo
        if engine == "NMAP" and not INSECURE_ACTIVE:
            QMessageBox.warning(self, "Nmap", "Nmap is only available if you activate Unsafe Mode.")
            self.cmb_engine.setCurrentText("NATIVE")
            return

        self.model.set_rows([])
        self.detail.clear()
        self.nmap_out.clear()
        self.lbl_status.setText("Starting…")

        self.btn_run.setEnabled(False)

        self.worker = PortsWorker(
            engine=engine,
            ports=ports,
            timeout_connect=float(self.spn_connect.value()),
            timeout_probe=float(self.spn_probe.value()),
            workers=int(self.spn_workers.value()),
            nmap_path=self.ed_nmap.text().strip(),
            nmap_args=self.ed_args.text().strip(),
        )
        self.worker.progress.connect(self.lbl_status.setText)
        self.worker.result.connect(self.on_rows)
        self.worker.nmap_output.connect(self.on_nmap_out)
        self.worker.error.connect(self.on_error)
        self.worker.finished.connect(lambda: self.btn_run.setEnabled(True))
        self.worker.start()

    def on_rows(self, rows):
        self.model.set_rows(rows)
        if rows:
            self.table.selectRow(0)
            self.show(rows[0])
        else:
            self.detail.setPlainText("No results.")

    def on_nmap_out(self, txt: str):
        self.nmap_out.append(txt)

    def on_error(self, msg: str):
        QMessageBox.warning(self, "Ports", msg)
        self.lbl_status.setText("Error.")

    def on_select(self, idx):
        r = self.model.get(idx.row())
        if r:
            self.show(r)

    def show(self, r):
        txt = (
            f"Host: {r.get('Host','')}\n"
            f"Port: {r.get('Port','')}\n"
            f"State: {r.get('State','')}\n"
            f"Service: {r.get('Service','')}\n"
            f"Confidence: {r.get('Confidence','')}\n"
            f"PID: {r.get('PID','')}\n"
            f"Process: {r.get('Process','')}\n"
            f"User: {r.get('User','')}\n"
            f"Path: {r.get('Path','')}\n"
        )
        if r.get("Notes"):
            txt += f"\nNotes:\n{r['Notes']}\n"
        if r.get("Evidence"):
            txt += f"\nEvidence:\n{r['Evidence']}\n"
        self.detail.setPlainText(txt)
