import subprocess
import shlex
import os


def run_nmap(nmap_path: str, args: str):
    """
    Executes nmap exactly with the provided arguments.
    Does not force localhost.
    Does not add targets.
    The user defines everything in args.
    """

    if not nmap_path:
        return 2, "", "Path to nmap.exe is empty."

    cmd = [nmap_path] + shlex.split(args, posix=False)

    creation_flags = 0
    startupinfo = None

    # Solo en Windows ocultamos la ventana
    if os.name == "nt":
        creation_flags = subprocess.CREATE_NO_WINDOW
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    p = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        creationflags=creation_flags,
        startupinfo=startupinfo
    )

    return p.returncode, p.stdout or "", p.stderr or ""
