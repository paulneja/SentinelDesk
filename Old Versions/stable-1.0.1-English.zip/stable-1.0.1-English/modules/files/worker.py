import os
from PySide6.QtCore import QThread, Signal
from modules.files import utils


class FilesWorker(QThread):
    progress = Signal(str)
    result = Signal(dict)
    error = Signal(str)

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self):
        try:
            p = self.path
            if not p or not os.path.isfile(p):
                self.error.emit("Invalid file.")
                return

            size = os.path.getsize(p)
            if size > utils.MAX_BYTES:
                self.error.emit(f"File too large ({utils.fmt_bytes(size)}). Maximum: 0.5 GB.")
                return

            # Basic immediate
            self.progress.emit("Reading metadata…")
            meta = {
                "Name": os.path.basename(p),
                "Path": p,
                "Size": f"{utils.fmt_bytes(size)} ({size} bytes)",
                "MIME": utils.detect_mime(p),
            }

            t = utils.file_times(p)
            meta["Creation (epoch)"] = str(int(t["Creation"]))
            meta["Modification (epoch)"] = str(int(t["Modification"]))
            meta["Access (epoch)"] = str(int(t["Access"]))

            # Hashes (streaming + progress)
            def cb(done, total):
                pct = int((done / total) * 100) if total else 0
                self.progress.emit(f"Hashing… {pct}%")

            hashes = utils.compute_hashes_stream(p, progress_cb=cb)
            meta.update(hashes)

            # Entropy (streaming)
            self.progress.emit("Calculating entropy…")
            ent = utils.entropy_stream(p)
            meta["Entropy (0-8)"] = f"{ent:.3f}"

            # Strings preview
            self.progress.emit("Extracting strings (preview)…")
            strings = utils.extract_strings_preview(p)

            # Hex preview
            self.progress.emit("Loading hex preview…")
            hex_bytes = utils.read_hex_preview(p)

            # Basic PE info
            pe = {}
            if utils.is_pe(p):
                self.progress.emit("PE detected. Reading header…")
                pe = utils.pe_basic_info(p)

            self.result.emit({
                "meta": meta,
                "strings": strings,
                "hex": hex_bytes,
                "pe": pe
            })
            self.progress.emit("Loaded.")

        except Exception as e:
            self.error.emit(str(e))
