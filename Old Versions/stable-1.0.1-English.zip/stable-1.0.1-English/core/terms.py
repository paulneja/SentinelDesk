import json
import os
from pathlib import Path
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel,
    QTextEdit, QPushButton, QHBoxLayout
)
from PySide6.QtCore import Qt


# -------------------------------
# Terms text
# -------------------------------
TERMS_TEXT = """
SentinelDesk — Terms and Conditions of Use

Copyright (C) 2026 PaulNeja & PN Security

SentinelDesk is free software distributed under the GNU General Public License (GPL v3 or later).
Its use implies full and unconditional acceptance of the following provisions.

1. Nature of the Software

SentinelDesk is a technical tool for system analysis, diagnostics, and evaluation.

It is intended exclusively for defensive auditing, analysis within personal environments, or systems where the user possesses explicit and verifiable authorization.

It has not been designed or authorized for the execution of offensive, intrusive, or illegal activities.

2. Usage Warning and Absolute Responsibility

Improper use of this tool may:

Constitute a cybercrime.

Generate criminal liability.

Trigger automatic defense mechanisms in networks and systems.

Produce permanent forensic records.

Be detected by monitoring and event correlation systems (SIEM).

Trigger alerts with Internet service providers.

Result in blocking of accounts, devices, or IP addresses.

The developer does not control or supervise how each user utilizes the software.

Any use outside personal environments or without explicit authorization from the system owner being audited is the sole responsibility of the user.

The developer (PaulNeja & PN Security) disclaims all civil, criminal, or administrative liability arising from improper, reckless, or illegal use of the software.

3. Prohibition of Illegal Activities

It is expressly prohibited to use SentinelDesk to:

Access systems without authorization.

Perform non-consensual scans.

Conduct intrusion testing on third-party infrastructures.

Interfere with, degrade, or interrupt services.

Violate privacy or data confidentiality.

The mere intention to use the tool for hostile purposes constitutes a violation of these conditions.

The user declares understanding that the activities mentioned above may be classified as crimes in multiple jurisdictions.

4. Disclaimer of Warranties

SentinelDesk is distributed “as is,” without any express or implied warranty.

No guarantee is provided regarding:

Absence of errors.

Uninterrupted operation.

Accuracy of results.

Fitness for a particular purpose.

Use of the software is entirely at the users own risk.

5. License and Redistribution

SentinelDesk is distributed under the GNU General Public License (GPL v3 or later), which permits:

Personal or commercial use.

Modification of the code.

Redistribution.

Provided that:

The same license is maintained.

Copyright notices are preserved.

Access to the source code is provided in case of redistribution.

The authorship of PaulNeja & PN Security may not be removed or altered.

6. Advanced Features and Experimental Mode

The software may include advanced functions that:

Generate identifiable network traffic.

Produce logs in monitoring systems.

Be interpreted as reconnaissance activity.

The user declares full understanding of the technical and legal implications of using such functions.

7. Acceptance

By using SentinelDesk, the user confirms:

Having read and understood this document.

Accepting all conditions without reservation.

Assuming full responsibility for the use of the software.

If the user does not agree with these conditions, they must refrain from using the program.
"""


# -------------------------------
# Safe path in AppData
# -------------------------------
def get_config_path():
    base = Path(os.getenv("APPDATA")) / "SentinelDesk"
    base.mkdir(parents=True, exist_ok=True)
    return base / "config.json"


# -------------------------------
# Acceptance verification
# -------------------------------
def terms_already_accepted():
    path = get_config_path()
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
        return data.get("terms_accepted", False)
    except:
        return False


# -------------------------------
# Save acceptance
# -------------------------------
def save_terms_acceptance():
    path = get_config_path()
    data = {"terms_accepted": True}
    path.write_text(json.dumps(data, indent=2))


# -------------------------------
# Dialog
# -------------------------------
class TermsDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Terms and Conditions")
        self.setMinimumSize(720, 520)

        layout = QVBoxLayout(self)

        title = QLabel("SentinelDesk — Terms and Conditions")
        title.setStyleSheet("font-size:16px; font-weight:bold;")
        layout.addWidget(title)

        text = QTextEdit()
        text.setReadOnly(True)
        text.setPlainText(TERMS_TEXT)
        layout.addWidget(text)

        buttons = QHBoxLayout()

        btn_decline = QPushButton("Decline")
        btn_accept = QPushButton("Accept")

        btn_decline.clicked.connect(self.reject)
        btn_accept.clicked.connect(self.accept)

        buttons.addWidget(btn_decline)
        buttons.addWidget(btn_accept)

        layout.addLayout(buttons)
