from pathlib import Path

from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget, QFrame, QLabel
)
from modules.files.page import FilesPage
from ui.topbar import TopBar
from ui.rightnav import RightNav
from modules.terminal.page import TerminalPage

from modules.logs.page import LogsPage
from modules.connections.page import ConnectionsPage
from modules.ports.page import PortsPage

APP_NAME = "SentinelDesk"


class PlaceholderPage(QWidget):
    def __init__(self, title: str, subtitle: str):
        super().__init__()

        from PySide6.QtWidgets import QScrollArea
        from PySide6.QtCore import Qt

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)

        container = QFrame()
        container.setObjectName("page")

        inner_layout = QVBoxLayout(container)
        inner_layout.setContentsMargins(18, 18, 18, 18)
        inner_layout.setSpacing(12)

        t = QLabel(title)
        t.setObjectName("pagetitle")
        t.setFont(QFont("Segoe UI", 18, QFont.Bold))

        s = QLabel(subtitle)
        s.setObjectName("pagesub")
        s.setWordWrap(True)
        s.setTextInteractionFlags(Qt.TextSelectableByMouse)

        inner_layout.addWidget(t)
        inner_layout.addWidget(s)
        inner_layout.addStretch(1)

        scroll.setWidget(container)
        main_layout.addWidget(scroll)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle(APP_NAME)
        self.resize(1350, 820)

        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(12)

        # Top bar
        self.top = TopBar(APP_NAME)
        root.addWidget(self.top)

        # Body
        body = QHBoxLayout()
        body.setSpacing(12)
        root.addLayout(body, 1)

        self.stack = QStackedWidget()

        self.nav = RightNav()
        self.nav.setFixedWidth(240)

        # Pages (order MUST match rightnav)
        self.page_dashboard = PlaceholderPage(
    "Dashboard",
"""SentinelDesk — Latest Unstable Build 1.0.1-dev >>>English version<<<

Welcome to SentinelDesk.

SentinelDesk is a local inspection and analysis tool designed to provide real-time technical visibility over system status, network activity, and file behavior. It does not automate decisions. It does not soften warnings. It provides structured information and direct technical control.

────────────────────────────────────────────

Current version: 1.0.1-dev (Unstable)
Status: Active development

This version is in experimental phase. It may contain errors, unexpected behaviors, or features in adjustment process. It is not recommended for use in production environments.

Changes in 1.0.1-dev
• Removed visible console opening in internal processes  
• Improvement in system event reading  
• File analysis optimization  
• General stability adjustments  

Functionalities may be modified without prior notice.

────────────────────────────────────────────

Previous stable version: 1.0.0

INCLUDED MODULES

Logs
• Structured parsing  
• Classification by severity  
• Internal categorization rules  

Connections
• Real-time TCP/UDP listing  
• Process, PID and user identification  

Ports
• Optimized Native engine (localhost)  
• Professional Nmap engine (Unsafe Mode)  
• Fingerprint identification  
• Strict separation between safe and unsafe mode  

Files
• Streaming technical analysis  
• SHA256 / MD5  
• Entropy calculation  
• Controlled strings preview  
• 500MB limit for stability  

Terminal
• Direct PowerShell execution  
• Command history  
• Live stdout/stderr capture  

────────────────────────────────────────────

Key fixes introduced in 1.0.0
• Removed crash due to incorrect event handling  
• Removed involuntary scan in Nmap engine  
• Thread and UI stability optimization  
• Import corrections in Nmap engine  
• Persistent Unsafe Mode control  
• Removal of massive reading blockages  

────────────────────────────────────────────

SentinelDesk 1.0.1-dev unstable is active.

© 2026 PN Security
"""

)

        self.page_logs = LogsPage()
        self.page_connections = ConnectionsPage()
        self.page_ports = PortsPage()
        self.page_files = FilesPage()
        self.page_terminal = TerminalPage()

        self.stack.addWidget(self.page_dashboard)    # 0
        self.stack.addWidget(self.page_logs)         # 1
        self.stack.addWidget(self.page_connections)  # 2
        self.stack.addWidget(self.page_ports)        # 3
        self.stack.addWidget(self.page_files)        # 4
        self.stack.addWidget(self.page_terminal)     # 5

        body.addWidget(self.stack, 1)
        body.addWidget(self.nav)

        self.setCentralWidget(central)

        # Load theme
        qss = Path(__file__).resolve().parent / "theme.qss"
        if qss.exists():
            self.setStyleSheet(qss.read_text(encoding="utf-8"))

        # Navigation wiring
        self.nav.list.currentRowChanged.connect(self.stack.setCurrentIndex)
