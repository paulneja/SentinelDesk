from PySide6.QtWidgets import QDialog
from ui.main_window import MainWindow
from core.terms import (
    terms_already_accepted,
    save_terms_acceptance,
    TermsDialog
)

APP_VERSION = "1.0"

# IMPORTANT: keep reference alive
_main_window = None


def start_application():
    """
    Version: 1.0.1-dev Unstable >>>English version<<<
    Controls terms and opens the main window.
    Returns the MainWindow if it continues, or None if it should close.
    """
    global _main_window

    # -------------------------------
    # Check previous acceptance
    # -------------------------------
    try:
        accepted = terms_already_accepted()
    except Exception:
        accepted = False

    # -------------------------------
    # Show terms if not accepted
    # -------------------------------
    if not accepted:
        dialog = TermsDialog()
        result = dialog.exec()

        if result != QDialog.Accepted:
            return None

        try:
            save_terms_acceptance()
        except Exception:
            return None

    # -------------------------------
    # Open main window
    # -------------------------------
    _main_window = MainWindow()
    _main_window.show()

    return _main_window
